
   _____                                                 
  / ____|                              /\                
 | |     ___  _ __ ___  _ __   __ _   /  \   _ __  _ __  
 | |    / _ \| '__/ _ \| '_ \ / _` | / /\ \ | '_ \| '_ \ 
 | |___| (_) | | | (_) | | | | (_| |/ ____ \| |_) | |_) |
  \_____\___/|_|  \___/|_| |_|\__,_/_/    \_\ .__/| .__/ 
                                            | |   | |    
                                            |_|   |_|    
by Stima Gemay K01
Indra Febrio Nugroho		13518016
Muhammad Fauzan Al-Ghifari	13518112
Reyvan Rizky Irsandy		13518136

======================================
Cara Menggunakan CoronaApp di Windows
======================================
1. Buka folder bin
2. jalankan CoronaApp.exe
3. Pastikan ada filekonfigurasi text1 dan tex2 yang sudah terisi
4. Masukan hari pada kolom
5. tekan show graph maka graph penyebaran virus akan ditampilkan

atau

1. Buka folder src
2. Jalankan CoronaApp.sln
3. buka Program.cs
4. tekan tombol f5 untuk masuk ke mode debug
5. program akan dijalankan
6. masukan hari pada kolom
7. tekan show graph maka graph penyebaran virus akan ditampilkan
8. file konfigurasi ada di StrAlgo2-18016\src\bin\Debug

Karena program menggunakan msagl
maka program tidak dapat dijalankan di ubuntu

